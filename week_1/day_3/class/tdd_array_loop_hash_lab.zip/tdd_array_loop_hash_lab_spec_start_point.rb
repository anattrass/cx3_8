require('minitest/autorun')
require_relative('./tdd_array_loop_hash_start_point_lab')

class Lab < MiniTest::Test

  def test_add_array_lengths

  end


  def test_sum_array

  end


  def test_find_item

  end


  def test_first_key_name

  end


  def test_array_of_capitals

  end

end
