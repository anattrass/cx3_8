class Action
  def self.all
    return ["savaged", 
            "chased", 
            "nibbled", 
            "drooled on", 
            "chewed on", 
            "beasted",
            "brutalised",
            "fried"]
  end
end